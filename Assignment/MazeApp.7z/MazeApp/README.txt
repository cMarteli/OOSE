*************
* MazeApp	*
*************
Written by: Caio Marteli 19598552

Description:



To run:

Compile the whole program using gradle.
:~/$ ./gradlew run
