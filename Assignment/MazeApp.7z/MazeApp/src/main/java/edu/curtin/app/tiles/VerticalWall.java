/**
 * Key.java
 * 2022/OOSE Assignment
 * @author Caio Marteli (19598552)
 */
package edu.curtin.app.tiles;

import java.awt.Point;

public class VerticalWall extends Wall
{

    public VerticalWall(Point l) {
        super(l);
        //TODO Auto-generated constructor stub
    }

    @Override
    public String description() {
        // TODO Auto-generated method stub
        return super.description();
    }

    @Override
    public Point getLocation() {
        // TODO Auto-generated method stub
        return super.getLocation();
    }


}
