*************
* MazeApp	*
*************
Written by: Caio Marteli 19598552

Description:
Traverse through a maze and try to find the exit!

To run:

Compile the whole program using gradle.
:~/$ ./gradlew run

Select new game from menu then load a valid input file.
Use the console to navigate hit the corresponding key then press 'enter'(N)orth (S)outh (E)ast (W)est

PS.
Input file provide is "input.txt" on root directory