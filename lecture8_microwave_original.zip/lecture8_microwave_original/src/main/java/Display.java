package edu.curtin.microwave.original;

/**
 * This is just a stub, to help demonstrate the MicrowaveController class.
 */
public class Display
{
    private int time = 0;
    public void update(int time) { this.time = time; }    
    public int getTime()         { return time; }
}
